import { Component, OnInit } from '@angular/core';
import { DatastoreService } from '../datastore.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(private store : DatastoreService) { }

  jsonData = [];
selItemVal = ''; 
  groupData = [];
  filterCards = [];
  modelData: any;
  detailsCard: any;

  ngOnInit(): void {

    this.store.loadData().subscribe(res => {
debugger;
    this.selItemVal = 'Group 1';
      let data : any;
      data = res;
      this.jsonData = data;

      for(let obj  of data.groups) {
        let grp :any = {};
        grp.value = obj.name;
        grp.id = obj.id;
        grp.cards = obj.cards;

        this.groupData.push(grp);
        this.filterCards =  this.groupData[0].cards;
      }

      this.modelData = this.groupData[0];

    },
    
    error => {
      console.log('error');
    })


  }

  selItem(event) {
    debugger;
    this.selItemVal = event;

    for(let obj of this.groupData) {
      if (this.selItemVal == obj.value) {

        this.filterCards = obj.cards;

      }
  }
 // this.filterCards = maincard;
  }

  loadCards(key) {debugger;
    let maincard = [];
    for(let obj of this.groupData) {
        if (this.selItemVal == obj.value) {

          maincard = obj.cards;

        }
    }
    this.filterCards = maincard;

    if (key == 1 ) {
      this.filterCards = [];
      let count = 0;
     for(let card of maincard) {
      if (count < 3) {
        this.filterCards.push(card)
        count++;
      }
    }
  }
      else if (key == 2) {
        this.filterCards = [];
        let count = 3;
        for(let i = 3 ;i < maincard.length ; i++) {

          this.filterCards.push(maincard[i])
        }
      }
     
    }


    loadDetails(card) {

      this.detailsCard = card;


    }
    
  

}
